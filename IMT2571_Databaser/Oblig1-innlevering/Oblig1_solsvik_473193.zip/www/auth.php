
<?php 

/**  
*    @author Jonas
*    @version 1.0
*
*    Created 28.08.16
*    File auth.php
*
*    Description 
*           Holds information about user-authentication.
*/

$DEFAULT_USER = 'Jonas J. Solsvik';
$DEFAULT_EMAIL = 'jonas.solsvik@gmail.com';

?>